from django.db import models

class Post(models.Model):
    titulo = models.CharField(max_length=200)  # Es como el nombre del dibujo
    contenido = models.TextField()             # Es como la historia o la descripción
    fecha = models.DateTimeField(auto_now_add=True)  # La fecha cuando lo creaste

    def __str__(self):
        return self.titulo
