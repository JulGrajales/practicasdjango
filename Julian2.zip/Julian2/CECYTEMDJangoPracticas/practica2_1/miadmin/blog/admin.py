from django.contrib import admin
from .models import Post

class PostAdmin(admin.ModelAdmin):
    list_display = ('titulo', 'autor', 'fecha_creacion', 'publicado')  # Muestra columnas en forma de tabla
    list_filter = ('publicado', 'fecha_creacion')  # Muestra filtros en la barra lateral
    search_fields = ('titulo', 'autor__username')  # Muestra caja de búsqueda (autor es FK, por eso usamos autor__username)

admin.site.register(Post, PostAdmin)
