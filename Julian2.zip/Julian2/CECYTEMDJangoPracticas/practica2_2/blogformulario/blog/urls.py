from django.urls import path
from . import views  # Importamos las vistas definidas en views.py

urlpatterns = [
    # Ruta para crear un nuevo post
    path('crear/', views.crear_post, name='crear_post'),

    # Ruta que se muestra después de crear el post con éxito
    path('exito/', views.post_exito, name='post_exito'),
]
