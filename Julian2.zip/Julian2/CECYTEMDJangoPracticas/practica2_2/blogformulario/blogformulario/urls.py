from django.contrib import admin
from django.urls import path, include  # ← Importamos include para enlazar otras urls

urlpatterns = [
    path('admin/', admin.site.urls),                 # Ruta al admin de Django
    path('blog/', include('blog.urls')),             # Ruta que enlaza con tu app blog
]
