from django.urls import path
from . import views

urlpatterns = [
    path('', views.lista_posts, name='lista_posts'),  # 👈 Nueva ruta principal
    path('editar/<int:post_id>/', views.editar_post, name='editar_post'),
    path('eliminar/<int:post_id>/', views.eliminar_post, name='eliminar_post'),
    path('detalle/<int:post_id>/', views.detalle_post, name='detalle_post'),
]
