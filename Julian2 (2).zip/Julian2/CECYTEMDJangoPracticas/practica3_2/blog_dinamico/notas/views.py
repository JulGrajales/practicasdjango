from django.shortcuts import render, get_object_or_404, redirect
from .models import Post
from .forms import PostForm

# Vista para editar
def editar_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    if request.method == 'POST':
        form = PostForm(request.POST, instance=post)
        if form.is_valid():
            form.save()
            return redirect('detalle_post', post_id=post.id)  # 👈 Aquí redirigimos al detalle
    else:
        form = PostForm(instance=post)
    return render(request, 'notas/editar_post.html', {'form': form})


# Vista para eliminar
def eliminar_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    if request.method == 'POST':
        post.delete()
        return redirect('lista_posts')  # Puedes cambiar por otra vista si no existe aún
    return render(request, 'notas/eliminar_post.html', {'post': post})


# ✅ NUEVA vista: Detalle del post
def detalle_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    return render(request, 'notas/detalle_post.html', {'post': post})
# Vista para listar todos los posts
def lista_posts(request):
    posts = Post.objects.all().order_by('-fecha')
    return render(request, 'notas/lista_posts.html', {'posts': posts})
