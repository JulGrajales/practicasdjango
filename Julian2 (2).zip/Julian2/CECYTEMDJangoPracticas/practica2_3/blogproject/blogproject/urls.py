from django.contrib import admin
from django.urls import path
from blog import views  # Importamos la vista directamente

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.listar_posts, name='inicio'),  # <-- ahora / muestra los posts
]      
# python manage.py runserver