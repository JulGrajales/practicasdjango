from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('hola.urls')),  # Esto conecta las URLs de tu app
]
